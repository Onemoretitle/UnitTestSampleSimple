using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp1;
using Microsoft.VisualStudio.TestPlatform.TestHost;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void IProgSum()
        {
            //arrange

            int x = 23;
            int y = 10;
            int expected = 33;

            //act

            int actual = IProgram.sumThis(x, y);

            //assert

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void IProgDiv()
        {
            //arrange

            double x = 100;
            double y = 10;
            int expected = 10;

            //act
            double actual = IProgram.divThis(x, y);

            //assert

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void IProgMult()
        {
            //arrange

            double x = 2.5;
            double y = 10;
            int expected = 25;

            //act
            double actual = IProgram.multThis(x, y);

            //assert

            Assert.AreEqual(expected, actual);
        }
    }
}
